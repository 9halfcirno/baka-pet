package com.cirno9half.bakapet;

import android.view.View;
import com.cirno9half.bakapet.R;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Toast;
import android.view.ViewGroup;
import android.view.LayoutInflater;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;

public class MainActivity extends AppCompatActivity {
    private static final int REQUEST_OVERLAY_PERMISSION = 1001; //
    private View settingOverlay; // 设置浮层根视图
    private int screenHeight;
    private OverlayWindow settingWindow;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // 设置全局异常捕获
        Thread.setDefaultUncaughtExceptionHandler((thread, throwable) -> {
            saveCrashLog(throwable);
            System.exit(1);
        });
        super.onCreate(savedInstanceState);

        // 检查悬浮窗权限
        if (checkOverlayPermission()) {
            startFloatService();
        } else {
            requestOverlayPermission();
        }

        setContentView(R.layout.activity_main);
        
        // 初始化设置窗口（从顶部滑入）
        settingWindow = new OverlayWindow.Builder(this)
                .setContentView(R.layout.setting_layout) // 简化后的布局
                .setAnimDirection(OverlayWindow.AnimDirection.TOP)
                .setDismissOnBackPressed(true)
                .setDismissOnOutsideClick(true)
                .build();

        // 绑定关闭按钮（注意：现在关闭按钮在卡片内部）
        MaterialButton btnClose = settingWindow.findViewById(R.id.btn_close_setting);
        if (btnClose != null) {
            btnClose.setOnClickListener(v -> settingWindow.dismiss());
        }

        // 左上角设置图标点击显示窗口
        MaterialButton btnSettings = findViewById(R.id.btn_settings);
        btnSettings.setOnClickListener(v -> settingWindow.show());
    }

    private void saveCrashLog(Throwable t) {
        try {
            // 获取 Android/data/com.cirno9half.bakapet/files 目录
            java.io.File dir = getExternalFilesDir(null);
            if (dir != null) {
                java.io.File file = new java.io.File(dir, "crash_log.txt");
                // 使用 true 表示追加模式，不加则每次覆盖
                java.io.PrintWriter pw = new java.io.PrintWriter(new java.io.FileWriter(file, true));
                pw.println("\n--- 崩溃时间: " + new java.util.Date().toString() + " ---");
                t.printStackTrace(pw);
                pw.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private boolean checkOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return Settings.canDrawOverlays(this); //
        }
        return true;
    }

    private void requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:" + getPackageName())); //
            startActivityForResult(intent, REQUEST_OVERLAY_PERMISSION);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_OVERLAY_PERMISSION) {
            if (checkOverlayPermission()) {
                Toast.makeText(this, "悬浮窗权限已授予", Toast.LENGTH_SHORT).show(); //
                startFloatService();
            } else {
                Toast.makeText(this, "未授予悬浮窗权限，无法启动", Toast.LENGTH_SHORT).show(); //
            }
        }
    }

    private void startFloatService() {
        Intent serviceIntent = new Intent(this, PetService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // Android 8.0 及以上使用前台服务启动
            startForegroundService(serviceIntent);
        } else {
            startService(serviceIntent);
        }
    }

}
