package com.cirno9half.bakapet;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.WindowManager;
import androidx.core.app.NotificationCompat;
import com.quickjs.JSContext;
import com.quickjs.JSValueHelper;
import com.quickjs.QuickJS;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
// 在 PetService 顶部添加 import
import android.content.BroadcastReceiver;
import android.content.IntentFilter;

public class PetService extends Service {

    private WindowManager wm;
    private QuickJS quickJS;
    private JSContext jsContext;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private final Map<Integer, PetInstance> instanceMap = new ConcurrentHashMap<>();
    private int nextId = 0;
    // 类内部添加成员
    private BroadcastReceiver configReceiver;
    // 音频播放
    private SoundPool soundPool;
    private final Map<String, Integer> soundCache = new HashMap<>();

    /** 宠物 Java 侧代理，直接操作 PetInstance，无需 JS 调用。 */
    public static class Pet {
        private final PetInstance instance;

        Pet(PetInstance instance) {
            this.instance = instance;
        }

        public void setPosition(int x, int y) {
            instance.setPosition(x, y);
        }

        public void move(int dx, int dy) {
            instance.move(dx, dy);
        }

        public int getX() {
            return instance.getX();
        }

        public int getY() {
            return instance.getY();
        }

        public void setScale(float sx, float sy) {
            instance.setScale(sx, sy);
        }

        public void updateImg(String path) {
            instance.updateImg(path);
        }

        public void setAttr(String key, Object val) {
            instance.setAttr(key, val);
        }

        public Object getAttr(String key) {
            return instance.getAttr(key);
        }

        public boolean hasAttr(String key) {
            return instance.hasAttr(key);
        }

        public void deleteAttr(String key) {
            instance.deleteAttr(key);
        }

        public boolean isDragging() {
            return instance.isDragging();
        }

        public void destroy() {
            instance.destroy();
        }

        public int getInstanceId() {
            return instance.getInstanceId();
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();

        // 全局崩溃日志
        Thread.setDefaultUncaughtExceptionHandler((t, e) -> {
            try {
                java.io.File f = new java.io.File(getExternalFilesDir(null), "crash_log.txt");
                java.io.PrintWriter pw = new java.io.PrintWriter(new java.io.FileWriter(f, true));
                e.printStackTrace(pw);
                pw.close();
            } catch (Exception ignored) {
            }
            System.exit(1);
        });

        // 前台通知
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            String CHANNEL_ID = "pet_service_channel";
            NotificationChannel channel = new NotificationChannel(
            CHANNEL_ID, "桌宠服务", NotificationManager.IMPORTANCE_LOW);
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.createNotificationChannel(channel);
            startForeground(1, new NotificationCompat.Builder(this, CHANNEL_ID)
                    .setContentTitle("Baka Pet 运行中")
                    .setContentText("多桌宠模式")
                    .setSmallIcon(android.R.drawable.ic_menu_info_details)
                    .build());
        }

        wm = (WindowManager) getSystemService(WINDOW_SERVICE);

        // 初始化音频（SoundPool）
        AudioAttributes audioAttrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            soundPool = new SoundPool.Builder()
                    .setMaxStreams(4)
                    .setAudioAttributes(audioAttrs)
                    .build();
        } else {
            soundPool = new SoundPool(4, AudioManager.STREAM_MUSIC, 0);
        }

        // 初始化共享 JS 环境
        quickJS = QuickJS.createRuntime();
        jsContext = quickJS.createContext();

        // 注入屏幕尺寸
        android.util.DisplayMetrics metrics = getResources().getDisplayMetrics();
        jsContext.executeVoidScript(String.format(
                "var device = { width: %d, height: %d };", metrics.widthPixels, metrics.heightPixels),
                "device.js");

        // 默认创建一只 cirno（可按需创建更多）
        addPet("pets/cirno");

        registerConfigReceiver();
    }

    // 在 onCreate() 末尾注册广播
    private void registerConfigReceiver() {
        configReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                updateDeviceInfo();
            }
        };
        IntentFilter filter = new IntentFilter(Intent.ACTION_CONFIGURATION_CHANGED);
        registerReceiver(configReceiver, filter);
    }

    private void updateDeviceInfo() {
        android.util.DisplayMetrics metrics = getResources().getDisplayMetrics();
        String script = String.format(
                "device.width = %d; device.height = %d;",
                metrics.widthPixels, metrics.heightPixels);
        jsContext.executeVoidScript(script, "device_update");
    }

    /** 为指定实例注册所有底层桥接方法（名称包含实例ID，防止冲突） */
    private void registerInstanceMethods(int instanceId) {
        String suffix = "_" + instanceId;

        jsContext.registerJavaMethod((receiver, args) -> {
            try {
                PetInstance inst = instanceMap.get(instanceId);
                if (inst != null)
                    inst.setPosition((int) args.getDouble(0), (int) args.getDouble(1));
                return null;
            } finally {
                JSValueHelper.close(args);
            }
        }, "_setPosition" + suffix);

        jsContext.registerJavaMethod((receiver, args) -> {
            try {
                PetInstance inst = instanceMap.get(instanceId);
                if (inst != null) inst.move((int) args.getDouble(0), (int) args.getDouble(1));
                return null;
            } finally {
                JSValueHelper.close(args);
            }
        }, "_move" + suffix);

        jsContext.registerJavaMethod((receiver, args) -> {
            try {
                PetInstance inst = instanceMap.get(instanceId);
                return inst != null ? inst.getX() : 0;
            } finally {
                JSValueHelper.close(args);
            }
        }, "_getX" + suffix);

        jsContext.registerJavaMethod((receiver, args) -> {
            try {
                PetInstance inst = instanceMap.get(instanceId);
                return inst != null ? inst.getY() : 0;
            } finally {
                JSValueHelper.close(args);
            }
        }, "_getY" + suffix);

        jsContext.registerJavaMethod((receiver, args) -> {
            try {
                PetInstance inst = instanceMap.get(instanceId);
                if (inst != null) inst.setScaleX((float) args.getDouble(0));
                return null;
            } finally {
                JSValueHelper.close(args);
            }
        }, "_setScaleX" + suffix);

        // 获取 scaleX
        jsContext.registerJavaMethod((receiver, args) -> {
            try {
                PetInstance inst = instanceMap.get(instanceId);
                return inst != null ? inst.getScaleX() : 1.0;
            } finally {
                JSValueHelper.close(args);
            }
        }, "_getScaleX" + suffix);

        jsContext.registerJavaMethod((receiver, args) -> {
            try {
                PetInstance inst = instanceMap.get(instanceId);
                if (inst != null)
                    inst.setScale((float) args.getDouble(0), (float) args.getDouble(1));
                return null;
            } finally {
                JSValueHelper.close(args);
            }
        }, "_setScale" + suffix);

        jsContext.registerJavaMethod((receiver, args) -> {
            try {
                PetInstance inst = instanceMap.get(instanceId);
                if (inst != null) inst.updateImg(args.getString(0));
                return null;
            } finally {
                JSValueHelper.close(args);
            }
        }, "_updateImg" + suffix);

        jsContext.registerJavaMethod((receiver, args) -> {
            try {
                PetInstance inst = instanceMap.get(instanceId);
                return inst != null && inst.isDragging();
            } finally {
                JSValueHelper.close(args);
            }
        }, "_dragging" + suffix);

        jsContext.registerJavaMethod((receiver, args) -> {
            try {
                PetInstance inst = instanceMap.get(instanceId);
                return inst != null && inst.getAnimationController().isLastFrame();
            } finally {
                JSValueHelper.close(args);
            }
        }, "_isLastFrame" + suffix);

        jsContext.registerJavaMethod((receiver, args) -> {
            try {
                PetInstance inst = instanceMap.get(instanceId);
                return inst != null ? inst.getWidth() : 0;
            } finally {
                JSValueHelper.close(args);
            }
        }, "_getImgWidth" + suffix);

        jsContext.registerJavaMethod((receiver, args) -> {
            try {
                PetInstance inst = instanceMap.get(instanceId);
                return inst != null ? inst.getHeight() : 0;
            } finally {
                JSValueHelper.close(args);
            }
        }, "_getImgHeight" + suffix);

        jsContext.registerJavaMethod((receiver, args) -> {
            try {
                PetInstance inst = instanceMap.get(instanceId);
                if (inst != null) inst.setAttr(args.getString(0), args.getString(1));
                return null;
            } finally {
                JSValueHelper.close(args);
            }
        }, "_setAttr" + suffix);

        jsContext.registerJavaMethod((receiver, args) -> {
            try {
                PetInstance inst = instanceMap.get(instanceId);
                return inst != null ? inst.getAttr(args.getString(0)) : null;
            } finally {
                JSValueHelper.close(args);
            }
        }, "_getAttr" + suffix);

        jsContext.registerJavaMethod((receiver, args) -> {
            try {
                PetInstance inst = instanceMap.get(instanceId);
                return inst != null && inst.hasAttr(args.getString(0));
            } finally {
                JSValueHelper.close(args);
            }
        }, "_hasAttr" + suffix);

        jsContext.registerJavaMethod((receiver, args) -> {
            try {
                PetInstance inst = instanceMap.get(instanceId);
                if (inst != null) inst.deleteAttr(args.getString(0));
                return null;
            } finally {
                JSValueHelper.close(args);
            }
        }, "_deleteAttr" + suffix);

        jsContext.registerJavaMethod((receiver, args) -> {
            try {
                PetInstance inst = instanceMap.get(instanceId);
                if (inst != null) inst.getAnimationController().switchTo(args.getString(0));
                return null;
            } finally {
                JSValueHelper.close(args);
            }
        }, "_animSwitchTo" + suffix);

        jsContext.registerJavaMethod((receiver, args) -> {
            try {
                PetInstance inst = instanceMap.get(instanceId);
                if (inst != null) inst.getActionController().switchTo(args.getString(0));
                return null;
            } finally {
                JSValueHelper.close(args);
            }
        }, "_actionSwitchTo" + suffix);

        // 播放音频桥接
        jsContext.registerJavaMethod((receiver, args) -> {
            try {
                String audioName = args.getString(0);
                PetInstance inst = instanceMap.get(instanceId);
                if (inst != null) playAudio(inst, audioName);
                return null;
            } finally {
                JSValueHelper.close(args);
            }
        }, "_playAudio" + suffix);
    }

    /** 根据桌宠屏幕位置播放双声道音频 */
    private void playAudio(PetInstance inst, String audioName) {
        String fullPath = inst.getAssetPath() + "/audio/" + audioName;
        Integer soundId = soundCache.get(fullPath);
        if (soundId == null) {
            try (AssetFileDescriptor afd = getAssets().openFd(fullPath)) {
                soundId = soundPool.load(afd, 1);
                soundCache.put(fullPath, soundId);
            } catch (Exception e) {
                e.printStackTrace();
                return;
            }
        }

        // 计算左右声道音量（基于宠物中心相对于屏幕中心的位置）
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        float screenW = dm.widthPixels;
        float petCenterX = inst.getX() + inst.getWidth() / 2f;
        float pan = (petCenterX - screenW / 2f) / (screenW / 2f); // -1（最左）到 1（最右）

        float leftVol = Math.min(1f, 1f - pan);
        float rightVol = Math.min(1f, 1f + pan);

        soundPool.play(soundId, leftVol, rightVol, 1, 0, 1.0f);
    }

    /** 在 JS 中创建该实例专属的 pet 对象 */
    private String createPetObject(int instanceId) {
        String varName = "__pet_" + instanceId;
        String suffix = "_" + instanceId;

        String script = String.format(
                "var %1$s = {\n" +
                        "  setPosition: _setPosition%2$s,\n" +
                        "  move: _move%2$s,\n" +
                        "  getX: _getX%2$s,\n" +
                        "  getY: _getY%2$s,\n" +
                        "  setScale: function(x, y) {\n" +
                        "    if (x === undefined) x = 1.0;\n" +
                        "    if (y === undefined) y = x;\n" +
                        "    _setScale%2$s(x, y);\n" +
                        "  },\n" +
                        "  updateImg: _updateImg%2$s,\n" +
                        "  setAttr: _setAttr%2$s,\n" +
                        "  getAttr: _getAttr%2$s,\n" +
                        "  hasAttr: _hasAttr%2$s,\n" +
                        "  deleteAttr: _deleteAttr%2$s,\n" +
                        "  animation: { switchTo: _animSwitchTo%2$s },\n" +
                        "  action: { switchTo: _actionSwitchTo%2$s },\n" +
                        "  playAudio: _playAudio%2$s,\n" +
                        "  _view: {},\n" +
                        "  getImageView: function() { return this._view; }\n" +
                        "};\n" +
                        "Object.defineProperty(%1$s, 'dragging', { get: _dragging%2$s });\n" +
                        "Object.defineProperty(%1$s, 'x', { get: _getX%2$s });\n" +
                        "Object.defineProperty(%1$s, 'y', { get: _getY%2$s });\n" +
                        "Object.defineProperty(%1$s.animation, 'isLastFrame', { get: _isLastFrame%2$s });\n" +
                        "Object.defineProperty(%1$s._view, 'width', { get: _getImgWidth%2$s });\n" +
                        "Object.defineProperty(%1$s._view, 'height', { get: _getImgHeight%2$s });\n" +
                        "Object.defineProperty(%1$s._view, 'scaleX', { \n" +
                        "  get: function() { return _getScaleX%2$s(); }, \n" +
                        "  set: function(v) { _setScaleX%2$s(v); } \n" +
                        "});",
                varName, suffix);

        jsContext.executeVoidScript(script, "pet_init_" + instanceId);
        return varName;
    }

    // ---------- 工厂方法 ----------
    public Pet addPet(String assetPath) {
        int id = nextId++;
        registerInstanceMethods(id);
        String petVarName = createPetObject(id);
        PetInstance inst = new PetInstance(this, id, assetPath, petVarName, mainHandler, jsContext);

        // 先将实例放入 Map（用于 JS 回调定位），再执行后续初始化
        instanceMap.put(id, inst);
        inst.init(); // 调用 PetInstance 的 init()（需确保该类有此方法）

        return new Pet(inst);
    }

    public void removePet(Pet pet) {
        PetInstance inst = instanceMap.remove(pet.getInstanceId());
        if (inst != null) {
            inst.destroy();
        }
    }

    public void removeAllPets() {
        for (int id : instanceMap.keySet()) {
            PetInstance inst = instanceMap.remove(id);
            if (inst != null) inst.destroy();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        removeAllPets();
        if (soundPool != null) {
            soundPool.release();
        }
        if (configReceiver != null) {
            unregisterReceiver(configReceiver);
        }

        if (jsContext != null) jsContext.close();
        if (quickJS != null) quickJS.close();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    // 内部使用
    WindowManager getWm() {
        return wm;
    }

    JSContext getJsContext() {
        return jsContext;
    }

    Handler getMainHandler() {
        return mainHandler;
    }
}
