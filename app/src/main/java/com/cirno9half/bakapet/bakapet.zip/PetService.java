package com.cirno9half.bakapet;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import androidx.core.app.NotificationCompat;
import com.quickjs.QuickJS;
import com.quickjs.JSContext;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.json.JSONObject;

public class PetService extends Service {
    private WindowManager wm;
    private WindowManager.LayoutParams params;
    private PetView petView;
    private QuickJS quickJS;
    private JSContext jsContext;
    private AnimationController animController;
    private ActionController actionController; // 【新增】动作控制器
    private boolean dragging = false;
    private final Map<String, Object> attrs = new HashMap<>();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override
    public void onCreate() {
        // 【新增】全局崩溃日志捕获器
        Thread.setDefaultUncaughtExceptionHandler((thread, throwable) -> {
            try {
                // 将日志保存到内部存储的 files 目录下，不需要动态申请存储权限
                java.io.File file = new java.io.File(getExternalFilesDir(null), "crash_log.txt");
                java.io.PrintWriter pw = new java.io.PrintWriter(new java.io.FileWriter(file));
                throwable.printStackTrace(pw);
                pw.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            System.exit(1); // 记录完毕后结束进程
        });

        super.onCreate();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            String CHANNEL_ID = "pet_service_channel";
            NotificationChannel channel = new NotificationChannel(
            CHANNEL_ID, "桌宠服务", NotificationManager.IMPORTANCE_LOW
            );
            NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager != null) manager.createNotificationChannel(channel);

            Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                    .setContentTitle("Baka Pet 运行中")
                    .setContentText("桌宠正在屏幕上活跃")
                    .setSmallIcon(android.R.drawable.ic_menu_info_details)
                    .build();
            startForeground(1, notification);
        }

        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        petView = new PetView(this);

        initWindow();

        // 核心控制器初始化顺序：先 JS环境 -> 后 控制器
        quickJS = QuickJS.createRuntime();
        jsContext = quickJS.createContext();

        animController = new AnimationController(this, petView);
        actionController = new ActionController(this, jsContext); // 【新增】传入 jsContext

        initJS(); // 注册 JS 桥梁
        autoLoad("pets/cirno");
        startLoop();
    }

    private void initWindow() {
        params = new WindowManager.LayoutParams(
        150, 150,
        Build.VERSION.SDK_INT >= 26 ? 2038 : 2002,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.LEFT;

        petView.setOnTouchListener(new View.OnTouchListener() {
            float ox, oy;

            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        dragging = true; // 开始拖动
                        ox = e.getRawX() - params.x;
                        oy = e.getRawY() - params.y;
                        break;
                    case MotionEvent.ACTION_MOVE:
                        params.x = (int) (e.getRawX() - ox);
                        params.y = (int) (e.getRawY() - oy);
                        wm.updateViewLayout(petView, params);
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        dragging = false; // 停止拖动
                        break;
                }
                return true;
            }
        });
        wm.addView(petView, params);
    }

private void initJS() {
    // 1. 注入屏幕宽高常量
    android.util.DisplayMetrics metrics = getResources().getDisplayMetrics();
    int screenWidth = metrics.widthPixels;
    int screenHeight = metrics.heightPixels;

    String deviceScript = String.format(
            "var device = { width: %d, height: %d };", screenWidth, screenHeight
    );
    jsContext.executeVoidScript(deviceScript, "device.js");

    // 2. 注册 Java 底层方法 (确保名字与后面 JS 调用一致)
    jsContext.registerJavaMethod((receiver, args) -> { setPosition(args.getInteger(0), args.getInteger(1)); return null; }, "_setPosition");
    jsContext.registerJavaMethod((receiver, args) -> { move(args.getInteger(0), args.getInteger(1)); return null; }, "_move");
    jsContext.registerJavaMethod((receiver, args) -> { return getX(); }, "_getX");
    jsContext.registerJavaMethod((receiver, args) -> { return getY(); }, "_getY");
    jsContext.registerJavaMethod((receiver, args) -> {
        float scale = (float) args.getDouble(0);
        mainHandler.post(() -> petView.setScaleX(scale));
        return null;
    }, "_setScaleX");

    jsContext.registerJavaMethod((receiver, args) -> { updateImg(args.getString(0)); return null; }, "_updateImg");
    
    // 注意：这里注册名为 _dragging，后面 JS 绑定也要用这个名字
    jsContext.registerJavaMethod((receiver, args) -> { return dragging; }, "_dragging");
    jsContext.registerJavaMethod((receiver, args) -> { return animController.isLastFrame(); }, "_isLastFrame");
    
    // 获取当前 View 的宽高
    jsContext.registerJavaMethod((receiver, args) -> { return params.width; }, "_getImgWidth");
    jsContext.registerJavaMethod((receiver, args) -> { return params.height; }, "_getImgHeight");

    // 属性操作
    jsContext.registerJavaMethod((receiver, args) -> { setAttr(args.getString(0), args.getString(1)); return null; }, "_setAttr");
    jsContext.registerJavaMethod((receiver, args) -> { Object val = getAttr(args.getString(0)); return val != null ? val.toString() : null; }, "_getAttr");
    jsContext.registerJavaMethod((receiver, args) -> { return hasAttr(args.getString(0)); }, "_hasAttr");
    jsContext.registerJavaMethod((receiver, args) -> { deleteAttr(args.getString(0)); return null; }, "_deleteAttr");

    // 控制器
    jsContext.registerJavaMethod((receiver, args) -> { animController.switchTo(args.getString(0)); return null; }, "_animSwitchTo");
    jsContext.registerJavaMethod((receiver, args) -> { actionController.switchTo(args.getString(0)); return null; }, "_actionSwitchTo");

    // 3. 构建 JS 对象层 (修复了原本字符串拼接的语法错误)
    String initScript = 
        "var pet = {\n" +
        "  setPosition: _setPosition,\n" +
        "  move: _move,\n" +
        "  getX: _getX,\n" +
        "  getY: _getY,\n" +
        "  updateImg: _updateImg,\n" +
        "  setAttr: _setAttr,\n" +
        "  getAttr: _getAttr,\n" +
        "  hasAttr: _hasAttr,\n" +
        "  deleteAttr: _deleteAttr,\n" +
        "  animation: { switchTo: _animSwitchTo },\n" +
        "  action: { switchTo: _actionSwitchTo },\n" +
        "  _view: {},\n" +
        "  getImageView: function() { return this._view; }\n" +
        "};\n" +
        "\n" +
        "// 绑定 pet.dragging 属性\n" +
        "Object.defineProperty(pet, 'dragging', { get: _dragging });\n" +
        "\n" +
        "// 绑定 pet.animation.isLastFrame 属性\n" +
        "Object.defineProperty(pet.animation, 'isLastFrame', { get: _isLastFrame });\n" +
        "\n" +
        "// 绑定 pet.getImageView() 返回对象的属性\n" +
        "Object.defineProperty(pet._view, 'width', { get: _getImgWidth });\n" +
        "Object.defineProperty(pet._view, 'height', { get: _getImgHeight });\n" +
        "Object.defineProperty(pet._view, 'scaleX', { \n" +
        "  set: function(v) { _setScaleX(v); } \n" +
        "});";

    jsContext.executeVoidScript(initScript, "init.js");
}


    // === 基础方法实现保持不变 ===
    public void setPosition(int x, int y) {
        params.x = x;
        params.y = y;
        mainHandler.post(() -> wm.updateViewLayout(petView, params));
    }

    public void move(int dx, int dy) {
        params.x += dx;
        params.y += dy;
        mainHandler.post(() -> wm.updateViewLayout(petView, params));
    }

    public int getX() {
        return params.x;
    }

    public int getY() {
        return params.y;
    }

    public void setAttr(String key, Object val) {
        attrs.put(key, val);
    }

    public Object getAttr(String key) {
        return attrs.get(key);
    }

    public void deleteAttr(String key) {
        attrs.remove(key);
    }

    public boolean hasAttr(String key) {
        return attrs.containsKey(key);
    }

    public void updateImg(String path) {
        mainHandler.post(() -> petView.updateImgFromAssets(path));
    }

    // === 自动化加载流程 ===
    private void autoLoad(String path) {
        try {
            JSONObject config = new JSONObject(readAsset(path + "/pet.json"));

            if (config.has("size")) {
                int px = (int) (Integer.parseInt(config.getString("size").replace("dp", "")) * getResources().getDisplayMetrics().density);
                params.width = params.height = px;
                mainHandler.post(() -> wm.updateViewLayout(petView, params));
            }

            JSONObject motions = config.getJSONObject("motions");
            for (Iterator<String> it = motions.keys(); it.hasNext(); ) {
                String key = it.next();
                animController.load(key, path + "/motions/" + motions.getString(key));
            }

            // 【修复】把加载和运行 actions 的逻辑交给专门的 actionController
            JSONObject actions = config.getJSONObject("actions");
            for (Iterator<String> it = actions.keys(); it.hasNext(); ) {
                String key = it.next();
                if (!key.equals("default")) {
                    String scriptStr = readAsset(path + "/actions/" + actions.getString(key));
                    actionController.load(key, scriptStr);
                }
            }

            // 【修复】原来此处你错误地调用了 animController 去切换 action，现已修正
            if (actions.has("default")) {
                actionController.switchTo(actions.getString("default"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void startLoop() {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                animController.update();
                actionController.update(); // 【重构】使用 actionController 进行轮询
                mainHandler.postDelayed(this, 16);
            }
        });
    }

    private String readAsset(String p) throws Exception {
        try (InputStream is = getAssets().open(p)) {
            byte[] b = new byte[is.available()];
            is.read(b);
            return new String(b, "UTF-8");
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (petView != null) wm.removeView(petView);
        if (jsContext != null) jsContext.close();
        if (quickJS != null) quickJS.close();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
