package com.cirno9half.bakapet;

import android.content.Context;
import android.graphics.*;
import android.util.LruCache;
import android.view.View;
import java.io.InputStream;

public class PetView extends View {
    private Bitmap currentBitmap;
    private final Paint paint;
    private final LruCache<String, Bitmap> bitmapCache;

    public PetView(Context context) {
        super(context);
        paint = new Paint();
        paint.setFilterBitmap(false); // 保持像素锐利
        paint.setAntiAlias(false);

        // 复刻原代码的 _maxCacheSize = 70
        bitmapCache = new LruCache<String, Bitmap>(70) {
            @Override
            protected void entryRemoved(boolean evicted, String key, Bitmap oldValue, Bitmap newValue) {
                if (oldValue != null && oldValue != currentBitmap && !oldValue.isRecycled()) {
                    oldValue.recycle(); 
                }
            }
        };
    }

    public void updateImgFromAssets(String path) {
        // android.util.Log.d("BakaPet", "尝试加载图片路径: " + path); // 添加这行
        Bitmap bmp = bitmapCache.get(path);
        if (bmp == null || bmp.isRecycled()) {
            try (InputStream is = getContext().getAssets().open(path)) {
                bmp = BitmapFactory.decodeStream(is);
                if (bmp != null) bitmapCache.put(path, bmp);
            } catch (Exception e) { e.printStackTrace(); }
        }
        this.currentBitmap = bmp;
        postInvalidate(); // 触发重绘
    }

    @Override
    protected void onDraw(Canvas canvas) {
        // 核心修复：清空画布，防止带有透明通道的连续帧产生叠加残影
        canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);

        if (currentBitmap != null && !currentBitmap.isRecycled()) {
            float scale = Math.min((float) getWidth() / currentBitmap.getWidth(), 
                                   (float) getHeight() / currentBitmap.getHeight());
            float dstW = currentBitmap.getWidth() * scale;
            float dstH = currentBitmap.getHeight() * scale;
            float dx = (getWidth() - dstW) / 2f;
            float dy = (getHeight() - dstH) / 2f;

            Rect srcRect = new Rect(0, 0, currentBitmap.getWidth(), currentBitmap.getHeight());
            RectF dstRect = new RectF(dx, dy, dx + dstW, dy + dstH);
            canvas.drawBitmap(currentBitmap, srcRect, dstRect, paint);
        }
    }

    public void clearCache() {
        bitmapCache.evictAll();
    }
}