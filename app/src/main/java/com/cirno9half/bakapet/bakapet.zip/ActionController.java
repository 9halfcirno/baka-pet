package com.cirno9half.bakapet;

import android.util.Log;
import com.quickjs.JSContext;

public class ActionController {
    private final PetService service;
    private final JSContext jsContext;
    private String currentId;

    public ActionController(PetService service, JSContext jsContext) {
        this.service = service;
        this.jsContext = jsContext;

        // 在 JS 环境中初始化全局变量，用于存储各个 action 对象以及当前运行的 action
        jsContext.executeVoidScript(
                "if(typeof __actions === 'undefined') { " +
                        "  var __actions = {}; " +
                        "  var __currentAction = null; " +
                        "}", "ActionControllerInit");
    }

    public void load(String id, String scriptContent) {
        // 1. 移除了 JS 内部的 try-catch，让异常直接穿透到 Java 层
        // 2. 确保脚本发生错误时，executeVoidScript 会抛出 Java 异常
        String wrapper = "(function() {\n" +
                "  var module = { exports: {} };\n" +
                "  var exports = module.exports;\n" +
                "  " + scriptContent + "\n" + // 直接执行内容
                "  __actions['" + id + "'] = module.exports;\n" +
                "})();";

        try {
            jsContext.executeVoidScript(wrapper, "action_" + id);
        } catch (Exception e) {
            // 这里会拦截到所有 JS 语法错误或运行错误
            // Android IDE 的 Logcat 会以红色高亮显示
            Log.e("QuickJS_Action_Load", "加载动作 '" + id + "' 失败！\n" +
                    "错误类型: " + e.getClass().getSimpleName() + "\n" +
                    "详细信息: " + e.getMessage());

            // 如果你的 QuickJS 封装类支持，还可以尝试打印 e.getStackTrace()
            // 但通常 e.getMessage() 已经包含了 QuickJS 格式化后的 JS 堆栈
        }
    }

    public void switchTo(String id) {
        if (id == null || id.isEmpty()) return;
        this.currentId = id;

        // 切换 action 并调用其 start 方法（如果存在）
        String script = "__currentAction = __actions['" + id + "'];\n" +
                "if(__currentAction && typeof __currentAction.start === 'function') {\n" +
                "  __currentAction.start(pet);\n" +
                "}";
        jsContext.executeVoidScript(script, "action_start_" + id);
    }

    public void update() {
        if (currentId == null) return;

        // 添加 try-catch，捕捉具体的 JS 执行错误并打印到 Logcat
        String script = "try {\n" +
                "  if(__currentAction && typeof __currentAction.update === 'function') {\n" +
                "    __currentAction.update(pet);\n" +
                "  }\n" +
                "} catch(e) {\n" +
                "  console.error('Update() 崩溃 [动作:' + '" + currentId + "']: ' + e.message + '\\n' + e.stack);\n" +
                "}";

        try {
            jsContext.executeVoidScript(script, "action_update");
        } catch (Exception e) {
            Log.e("ActionController", "致命框架级异常", e);
        }
    }

}