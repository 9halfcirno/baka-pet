package com.cirno9half.bakapet;

import android.content.Context;
import org.json.JSONObject;
import java.io.InputStream;
import java.util.*;

public class AnimationController {
    private final PetService service;
    private final PetView view;
    private final Map<String, Anim> anims = new HashMap<>();
    private String currentId;
    private int frame = 0;
    private long lastTime = 0;

    private static class Anim {
        int frameNum, interval;
        String next, baseUrl;
    }

    public AnimationController(PetService s, PetView v) {
        this.service = s;
        this.view = v;
    }

    public void load(String id, String path) {
        try (InputStream is = service.getAssets().open(path + "/meta.json")) {
            byte[] b = new byte[is.available()];
            is.read(b);
            JSONObject json = new JSONObject(new String(b));
            Anim a = new Anim();
            a.frameNum = json.getInt("frame_num");
            a.interval = json.optInt("frame_interval", 100); // 默认 100ms
            a.next = json.optString("next", null);
            a.baseUrl = path;
            anims.put(id, a);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void switchTo(String id) {
        if (id.equals(currentId) || !anims.containsKey(id)) return;
        currentId = id;
        frame = 0;
        lastTime = System.currentTimeMillis();
        updateUI();
    }

    // 在 AnimationController.java 中添加
    public boolean isLastFrame() {
        if (currentId == null) return false;
        Anim a = anims.get(currentId);
        if (a == null) return false;
        // 如果当前帧 + 1 等于总帧数，则说明是最后一帧
        return (frame + 1) >= a.frameNum;
    }

    public void update() {
        if (currentId == null) return;
        Anim a = anims.get(currentId);
        long now = System.currentTimeMillis();
        if (now - lastTime > a.interval) {
            frame++;
            lastTime = now;
            if (frame >= a.frameNum) {
                if (a.next != null && anims.containsKey(a.next)) {
                    switchTo(a.next); // 自动播放下一段
                } else {
                    frame = 0; // 循环
                    updateUI();
                }
            } else {
                updateUI();
            }
        }
    }

    private void updateUI() {
        service.updateImg(anims.get(currentId).baseUrl + "/" + frame + ".png");
    }
}