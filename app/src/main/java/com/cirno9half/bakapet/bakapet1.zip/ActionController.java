package com.cirno9half.bakapet;

import android.util.Log;
import com.quickjs.JSContext;

public class ActionController {
    private final PetService service;
    private final JSContext jsContext;
    private String currentId;

    public ActionController(PetService service, JSContext jsContext) {
        this.service = service;
        this.jsContext = jsContext;

        // 【修改点1】：在这里提前定义好帧循环需要执行的函数 __doUpdate()
        jsContext.executeVoidScript(
                "if(typeof __actions === 'undefined') { " +
                        "  var __actions = {}; " +
                        "  var __currentAction = null; " +
                        "}\n" +
                        "function __doUpdate() {\n" +
                        "  if(__currentAction && typeof __currentAction.update === 'function') {\n" +
                        "    __currentAction.update(pet);\n" +
                        "  }\n" +
                        "}", "ActionControllerInit");
    }

    public void load(String id, String scriptContent) {
        String wrapper = "(function() {\n" +
                "  var module = { exports: {} };\n" +
                "  var exports = module.exports;\n" +
                "  " + scriptContent + "\n" +
                "  __actions['" + id + "'] = module.exports;\n" +
                "})();";

        try {
            jsContext.executeVoidScript(wrapper, "action_" + id);
        } catch (Exception e) {
            Log.e("QuickJS_Action_Load", "加载动作 '" + id + "' 失败！\n" + e.getMessage());
        }
    }

    public void switchTo(String id) {
        if (id == null || id.isEmpty()) return;
        this.currentId = id;

        String script = "__currentAction = __actions['" + id + "'];\n" +
                "if(__currentAction && typeof __currentAction.start === 'function') {\n" +
                "  __currentAction.start(pet);\n" +
                "}";
        jsContext.executeVoidScript(script, "action_start_" + id);
    }

    public void update() {
        if (currentId == null) return;

        try {
            synchronized (service.getJsLock()) {
                // 【修改点2】：只调用固定函数，使用 executeVoidScript 避免产生返回值对象
                jsContext.executeVoidScript("__doUpdate();", "action_update");
            }
        } catch (Exception e) {
            Log.e("ActionController", "Update 崩溃: " + e.getMessage());
        }
    }
}